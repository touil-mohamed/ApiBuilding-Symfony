<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Validator\Constraints as Assert;
use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\PieceRepository;
#[ORM\Entity(repositoryClass: PieceRepository::class)]
/**
 * Class Consent
 * @ApiResource
 * @ORM\Entity
 */
class Piece
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255)]
    private $nom;

    #[ORM\Column(type: 'integer')]
    private $personnes;

    #[ORM\Column(type: 'text')]
    private $lien_Building;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPersonnes(): ?int
    {
        return $this->personnes;
    }

    public function setPersonnes(int $personnes): self
    {
        $this->personnes = $personnes;

        return $this;
    }

    public function getLienBuilding(): ?string
    {
        return $this->lien_Building;
    }

    public function setLienBuilding(string $lien_Building): self
    {
        $this->lien_Building = $lien_Building;

        return $this;
    }
    public function __toString()
    {
        return $this->nom;
        return $this->id;
    }
}
