<?php

namespace App\Controller;
use App\Entity\Piece;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\PieceRepository;
class PieceController extends AbstractController
{
    #[Route('/piece', name: 'app_piece')]
    public function index(EntityManagerInterface $el): Response
    {
        $piece = $el->getRepository(Piece::class)->findAll();
        //dd($piece);
        return $this->render('piece/index.html.twig', [
            'piece' => $piece
        ]);
    }
}
