<?php

namespace App\Controller;

use App\Entity\Organisation;
use App\Repository\OrganisationRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
class BuildingController extends AbstractController
{
    #[Route('/building', name: 'app_building')]
    public function index(EntityManagerInterface $em): Response
    {
        // ON Apelle la liste de tousnles building
        $building = $em->getRepository(Organisation::class)->findAll();
        //dd($building);
        return $this->render('building/index.html.twig', [
            'building' => $building
        ]);
    }
}
